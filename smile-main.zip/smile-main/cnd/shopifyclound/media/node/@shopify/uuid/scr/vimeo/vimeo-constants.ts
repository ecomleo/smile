export const VIDEO_TYPE = 'vimeo';
